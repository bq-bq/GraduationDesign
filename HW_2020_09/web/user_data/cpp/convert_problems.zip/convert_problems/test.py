import os, json, time

def read(path):
	data = []
	with open(path) as fp:
		for line in fp:
			line = line.strip()
			if line == '': continue
			data.append(line.split(', '))
	return data

def text_to_time(text):
	date_formats = ('', '%d %b %y', '%Y-%m-%d', '%d-%b-%Y', '%m/%d/%Y', '%Y')
	time_formats = ('', '%I:%M%p', '%H:%M:%S', '%H:%M', '%M:%S', '%H:%M:%S.%f')
	for date_format in date_formats:
		for time_format in time_formats:
			datetime_format = (date_format + ' ' + time_format).strip()
			try:
				ts = time.strptime(text, datetime_format)
				return time.mktime(ts)
			except ValueError:
				pass
			except OverflowError:
				pass
	assert False, '数据格式错误: 不能转换为类型 time: %s' % text

if __name__ == '__main__':
	index = read(os.path.join('problem', 'index.txt'))
	def norm_int(x):
		try:
			return ('0000' + str(int(x)))[-4:]
		except:
			return x
	def sort_key(x):
		x = [x1.strip() for x1 in x[0].split(' ') if x1.strip() != '']
		x = [x2.strip() for x1 in x for x2 in x1.split('.') if x2.strip() != '']
		x = [norm_int(x1) for x1 in x]
		return x
	index = sorted(index, key=sort_key)
	def norm_text(t):
		return t.replace('\\n', '\n').replace('\\t', '\t').replace('\\c', ',').replace('\\\\', '\\')
	names = set()

	templ ='''        [
            %s,
            %s,
            %s,
            %s,
            %s,
            %f,
            %f
        ],'''

	time1 = text_to_time('2020-04-01 12:00:00')
	for i1 in index:
		title = norm_text(i1[0])
		code = i1[3]
		problem = read(os.path.join('problem', code+'.problem.txt'))
		_, problem_type, _, _, _, text, _, main, _, ex_in, _, source = problem[0]
		assert problem_type in ('C程序设计题', 'C++程序设计题')
		problem_type = ('C' if problem_type == 'C程序设计题' else 'C++')
		if title.startswith('C语言'): title = title[3:]
		if title.startswith('C++'): title = title[3:].strip()
		if title.endswith('(C)'): title = title[:-3].strip()
		if title.endswith('(C++)'): title = title[:-5].strip()
		title = title + ' (%s)' % problem_type
		assert title not in names
		names.add(title)
		# print(title)
		title = json.dumps(title)
		text = json.dumps(norm_text(text))
		main = json.dumps(norm_text(main))
		ex_in = json.dumps("print('''"+norm_text(ex_in)+"''')")
		source = json.dumps(norm_text(source))
		print(templ % (title, text, main, source, ex_in, time1, time1))

